import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch import device
from sklearn.decomposition import NMF
import xgboost as xgb

from torch_geometric.nn import GCNConv
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.metrics import roc_auc_score, average_precision_score, accuracy_score, f1_score, matthews_corrcoef, recall_score, precision_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import matthews_corrcoef, confusion_matrix
import torch.nn.functional as F
import random
#
#
#
lnc_dis_2 = pd.read_csv(r"D:\张清宝论文\LDA\dataset_3\data\data1\LDA.csv",header = None) # (240,412)
mi_dis_2 = pd.read_csv(r"D:\张清宝论文\LDA\dataset_3\data\data1\MDA.csv",header = None) # (495,412)
lnc_mi_2 = pd.read_csv(r"D:\张清宝论文\LDA\dataset_3\data\data1\LMA.csv",header = None ) # (240,495)
di_di_semantics_2 = pd.read_csv(r"D:\张清宝论文\LDA\dataset_3\data\data1\DSS.csv",header = None)
lnc_lnc_function_2 = pd.read_csv(r"D:\张清宝论文\LDA\dataset_3\data\data1\LFS.csv",header = None)
mi_mi_function_2 = pd.read_csv(r"D:\张清宝论文\LDA\dataset_3\data\data1\MFS.csv",header = None)
# DGS = pd.read_csv(r"D:\张清宝论文\瞎搞\dataset_3\data\DGS.csv",header=None)
# LGS = pd.read_csv(r"D:\张清宝论文\瞎搞\dataset_3\data\LGS.csv",header=None)





def calculate_kernel_bandwidth(A):
    IP_0 = 0
    for i in range(A.shape[0]):
        # print(A.shape)
        IP = np.square(np.linalg.norm(A.T[i]))
        # print(IP)
        IP_0 += IP
    lambd = 1/((1/A.shape[0]) * IP_0)
    return lambd

def calculate_GaussianKernel_sim(A):

    kernel_bandwidth = calculate_kernel_bandwidth(A)
    gauss_kernel_sim = np.zeros((A.shape[0],A.shape[0]))
    for i in range(A.shape[0]):
        for j in range(A.shape[0]):
            gaussianKernel = np.exp(-kernel_bandwidth * np.square(np.linalg.norm(A.T[i] - A.T[j])))
            gauss_kernel_sim[i][j] = gaussianKernel

    return gauss_kernel_sim

GL1 = calculate_GaussianKernel_sim(lnc_dis_2)
print(GL1.shape)
GD1 = calculate_GaussianKernel_sim(lnc_dis_2.T)
print(GD1.shape)
GM1 = calculate_GaussianKernel_sim(mi_dis_2)
print(GM1.shape)
GD2 = calculate_GaussianKernel_sim(mi_dis_2.T)
print(GD2.shape)
GL2 = calculate_GaussianKernel_sim(lnc_mi_2)
print(GL2.shape)
GM2 = calculate_GaussianKernel_sim(lnc_mi_2.T)
print(GM2.shape)
#

def dis_fusion_sim (G1, G2, SD):

    D_fuse = (SD + (G1 + G2)/2)/2

    return D_fuse
SD = dis_fusion_sim(GD1,GD2,di_di_semantics_2)
print(SD)
print(SD.shape)
# SD_tensor = torch.from_numpy(SD.values)
# SD= torch.matmul(SD_tensor, d)
# print(SD.shape)




def fusion_sim(FL, GL1, GL2):
    # FL: lncRNA的功能相似性矩阵
    # GL1: lncRNA的GIPK相似性矩阵
    # GL2: lncRNA的GIPK相似性矩阵

    # 创建一个与FL矩阵相同大小的SL矩阵
    SL = pd.DataFrame(np.zeros_like(FL.values), index=FL.index, columns=FL.columns)

    # 遍历FL矩阵的每个元素
    for i in range(FL.shape[0]):
        for j in range(FL.shape[1]):
            # 检查FL矩阵中的元素是否为0
            if FL.iloc[i, j] != 0:
                SL.iloc[i, j] = FL.iloc[i, j]
            else:
                SL.iloc[i, j] = (GL1.iloc[i, j] + GL2.iloc[i, j]) / 2

    return SL
# 创建FL、GL1和GL2矩阵（示例数据）
FL = pd.DataFrame(lnc_lnc_function_2)
GL1 = pd.DataFrame(GL1)
GL2 = pd.DataFrame(GL2)

# 调用函数进行计算
SL = fusion_sim(FL, GL1, GL2)

print(SL)
print(SL.shape)
# SL_tensor = torch.from_numpy(SL.values)
# SL= torch.matmul(SL_tensor, l)
# print(SL.shape)

# #
FM = pd.DataFrame(mi_mi_function_2)
GM1 = pd.DataFrame(GM1)
GM2 = pd.DataFrame(GM2)

SM = fusion_sim(FM, GM1, GM2)
# print(SM)
# print(SM.shape)
# SM_tensor = torch.from_numpy(SM.values)
# SM= torch.matmul(SM_tensor, m)
# print(SM.shape)
def construct_graph(lncRNA_disease,  miRNA_disease, miRNA_lncRNA, lncRNA_sim, miRNA_sim, disease_sim ):
    lnc_dis_sim = np.hstack((lncRNA_sim, lncRNA_disease, miRNA_lncRNA.T))
    # 这行代码将三个矩阵 lncRNA_sim、lncRNA_disease 和 miRNA_lncRNA 进行水平堆叠，也就是将它们连接在一起，创建了一个新的矩阵 lnc_dis_sim。

    dis_lnc_sim = np.hstack((lncRNA_disease.T,disease_sim, miRNA_disease.T))
    # 这行代码类似地将三个矩阵 lncRNA_disease.T、disease_sim 和 miRNA_disease.T 进行水平堆叠，创建了一个新的矩阵 dis_lnc_sim。

    mi_lnc_dis = np.hstack((miRNA_lncRNA,miRNA_disease,miRNA_sim))
    # 这行代码将三个矩阵 miRNA_lncRNA、miRNA_disease 和 miRNA_sim 进行水平堆叠，创建了一个新的矩阵 mi_lnc_dis。

    matrix_A_1 = np.vstack((lnc_dis_sim,dis_lnc_sim,mi_lnc_dis))          #
    # 这行代码将前面创建的三个矩阵 lnc_dis_sim、dis_lnc_sim 和 mi_lnc_dis 进行垂直堆叠，也就是将它们连接在一起，创建了一个最终的矩阵 matrix_A。
    return matrix_A_1
#
mi_lnc_2 = lnc_mi_2.T
matrix_A_2 = construct_graph(lnc_dis_2,mi_dis_2,mi_lnc_2,SL,SM,SD)
print(matrix_A_2)
print(matrix_A_2.shape)
# #
# 创建NMF实例，并指定特征的数量
nmf = NMF(n_components=2)

# 执行非负矩阵分解
W = nmf.fit_transform(matrix_A_2)  # 特征矩阵
H = nmf.components_  # 样本权重矩阵

# 打印原始矩阵
print("原始矩阵 X:")
print(matrix_A_2)

# 打印分解后的矩阵
print("特征矩阵 W:")
print(W)
print(W.shape)
print("样本权重矩阵 H:")
print(H)
print(H.shape)

# 重构原始矩阵
X_reconstructed_2 = np.dot(W, H)

# 打印重构后的矩阵
print("重构后的矩阵:")
print(X_reconstructed_2)
print(X_reconstructed_2.shape)
#
U, S3, Vt = np.linalg.svd(X_reconstructed_2)
feature_2 = np.hstack((U, Vt))
print(feature_2.shape)


#
def LA_norm(adj):
    degree = np.array(adj.sum(1))
    D = []
    for i in range(len(degree)):
        if degree[i] != 0:
            de = np.power(degree[i], -0.5)

            D.append(de)
        else:
            D.append(0)
    degree = np.diag(np.array(D))
    norm_A = degree.dot(adj).dot(degree)
    return norm_A
#
#
class GCN(nn.Module):
    def __init__(self, in_size, out_size):
        super(GCN, self).__init__()
        self.in_size = in_size
        self.out_size = out_size


        self.weight = nn.Parameter(torch.FloatTensor(in_size, out_size))
        nn.init.xavier_uniform_(self.weight.data, gain=1.414)


    def forward(self, adj, features):
       out = torch.mm(adj, features)
       out = torch.mm(out,self.weight)
       return out



def mish(x):
    x = torch.tensor(x, dtype=torch.float)
    return x * torch.tanh(torch.nn.functional.softplus(x))





class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, n_calss):
        super(Encoder, self).__init__()
        self.gcn1 = GCN(input_dim, hidden_dim + n_calss)
        # self.prelu1 = nn.PReLU(hidden_dim)
        # self.gcn2 = GCNConv(hidden_dim, n_calss)
        # self.prelu2 = nn.PReLU(n_calss)
        self.mish = mish
        self.last_linear = torch.nn.Linear(hidden_dim + n_calss, n_calss)

        # self.dropout = nn.Dropout(p=0.5)



    def forward(self, x, adj, corrupt=True):
        if corrupt:
            perm = torch.randperm(x.shape[0])
            x = x[perm]
            # 随机翻转特征值
            flip_mask = torch.randint(0, 2, size=x.shape).bool()
            x = torch.where(flip_mask, -x, x)

        x1 = self.gcn1(adj, x)
        x1 = self.mish(x1)
        # x1 = self.dropout1(x1)  # 使用 dropout

        x2 = self.last_linear(x1)
        x2 = self.mish(x2)

        # x2 = self.dropout2(x2)  # 使用 dropout

        return x2




class DISA(nn.Module):
    def __init__(self, hidden_dim):
        super(DISA, self).__init__()
        self.weight = nn.Parameter(torch.Tensor(hidden_dim, hidden_dim))
        nn.init.xavier_uniform_(self.weight.data, gain=1.414)
    def forward(self, x, summary):
        x = torch.matmul(x, torch.matmul(self.weight, summary))
        return x

class MDGCLLDA(nn.Module):
    def __init__(self, input_dim, hidden_dim,output_dim):
        super(MDGCLLDA, self).__init__()
        self.encoder = Encoder(input_dim, hidden_dim,output_dim)
        self.discriminator = DISA(output_dim)
        # self.loss = nn.BCEWithLogitsLoss()
        self.sigmoid = nn.Sigmoid()
        self.loss = nn.BCELoss()
    def forward(self, edge_index, x ):
        positive = self.encoder(x, edge_index, corrupt=False)
        negative = self.encoder(x, edge_index, corrupt=True)
        summary = torch.sigmoid(positive.mean(dim=0))
        # summary = torch.std(positive, dim=0)
        # summary = torch.sigmoid(positive.std(dim=0))

        # print("summary: ",summary.shape)
        positive_D = self.discriminator(positive, summary)
        negative_D = self.discriminator(negative, summary)
        positive_D = self.sigmoid(positive_D)
        negative_D = self.sigmoid(negative_D)
        l1 = self.loss(positive_D, torch.ones_like(positive_D))
        l2 = self.loss(negative_D, torch.zeros_like(negative_D))
        # l1 = self.loss(torch.clamp(positive_D, 0, 1), torch.ones_like(positive_D))
        # l2 = self.loss(torch.clamp(negative_D, 0, 1), torch.zeros_like(negative_D))

        L = l1 + l2
        return L, positive






def train(la_A_2, Epoch, in_features, N_HID, out_features, LR):

    G = MDGCLLDA(input_dim=in_features, hidden_dim=N_HID, output_dim=out_features)
    # G_optimizer = torch.optim.Adam(G.parameters(), lr=LR)
    G_optimizer = torch.optim.Adam(G.parameters(), lr=LR, weight_decay=0.001)

    A_laplacians = torch.from_numpy(la_A_2).float()
    X = torch.from_numpy(feature_2).float()
    if torch.cuda.is_available():
        G = G.cuda()

        A_laplacians = A_laplacians.cuda()
        X = X.cuda()

    for epoch in range(Epoch):
        G_loss, embedding = G(A_laplacians, X)

        G_optimizer.zero_grad()
        G_loss.backward()
        G_optimizer.step()
        # print(embedding)
        print('Epoch: ', epoch, '| train G_loss: %.10f' % G_loss.item())




    # print(embedding)
    #
    df = pd.DataFrame(embedding.detach().numpy())  # 将张量转换为 Pandas DataFrame
    df.to_csv("./dataset_3/embedding_result_11.csv", index=False)








if __name__ == '__main__':


    Epoch = 500
    in_features = 2294
    N_HID = 1024
    out_features = 512
    LR = 0.01

    la_A_2 = LA_norm(matrix_A_2)

    # print(la_A.shape)
    train(la_A_2, Epoch, in_features, N_HID, out_features, LR)

# 读取 CSV 文件
df = pd.read_csv(r'D:\张清宝论文\瞎搞\dataset_3\embedding_result_11.csv')



# 提取 lncRNA 部分（前 240 行）
lncRNA_2 = df.iloc[:240, :]
print(lncRNA_2.shape)

# 提取 disease 部分（中间 405 行）
disease_2 = df.iloc[240:652, :]
print(disease_2.shape)
# disease_2.to_csv('dataset_3/disease_2.csv', index=False)
# 提取 miRNA 部分（后 495 行）
miRNA_2 = df.iloc[652:, :]

# lnc_dis_2 = pd.read_csv(r"D:\张清宝论文\瞎搞\dataset_2\lnc_di.csv", header = None)

# features = pd.concat([lncRNA_2, disease_2], axis=0).values
zero_index = []
one_index = []
for i in range(lnc_dis_2.shape[0]):
    for j in range(lnc_dis_2.shape[1]):
        if lnc_dis_2.iloc[i, j] < 1:
            zero_index.append([i, j])
        if lnc_dis_2.iloc[i, j] >= 1:
            one_index.append([i, j])

posi_list = []
for index in one_index:
    lnc_index = index[0]
    disease_index = index[1]
    if lnc_index < lncRNA_2.shape[0] and disease_index < disease_2.shape[0]:
        posi = lncRNA_2.iloc[lnc_index, :].tolist() + disease_2.iloc[disease_index, :].tolist() + [1, 0]
        posi_list.append(posi)

unlabelled_list = []
for index in zero_index:
    lnc_index = index[0]
    disease_index = index[1]
    if lnc_index < lncRNA_2.shape[0] and disease_index < disease_2.shape[0]:
        unlabelled = lncRNA_2.iloc[lnc_index, :].tolist() + disease_2.iloc[disease_index, :].tolist() + [0, 1]
        unlabelled_list.append(unlabelled)


posi_data = np.array(posi_list)
print(posi_data)
print(posi_data.shape)

nega_data = np.array(unlabelled_list)
print(nega_data)
print(nega_data.shape)

nega_data_1 = random.sample(nega_data.tolist(), len(posi_data))
nega_data_1 = np.array(nega_data_1)
print(nega_data_1)
print(nega_data_1.shape)

data = np.concatenate((posi_data, nega_data_1))
X = data[:, :-2]
y = data[:, -2]
print(X)
print(X.shape)
print(y)
print(y.shape)






# 定义五折交叉验证
kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)

# 定义性能指标列表
auc_scores = []
aupr_scores = []
acc_scores = []
f1_scores = []
mcc_scores = []
recall_scores = []
precision_scores = []  # 新增 precision 的列表

# 进行五次独立的训练
for i, (train_index, test_index) in enumerate(kfold.split(X, y)):
    print(f"Training Iteration {i+1}")

    # 划分训练集和测试集
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]

    # 创建XGBoost分类器并设置超参数
    model = xgb.XGBClassifier(
        learning_rate=0.1,
        n_estimators=300,
        max_depth=5,
        reg_alpha=0.001,
        reg_lambda=0.1
    )

    # 训练模型
    model.fit(X_train, y_train)

    # 在测试集上进行预测
    y_pred = model.predict(X_test)

    # 计算性能指标
    auc = roc_auc_score(y_test, y_pred)
    aupr = average_precision_score(y_test, y_pred)
    acc = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    mcc = matthews_corrcoef(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)  # 新增 precision 的计算

    # 将性能指标加入列表
    auc_scores.append(auc)
    aupr_scores.append(aupr)
    acc_scores.append(acc)
    f1_scores.append(f1)
    mcc_scores.append(mcc)
    recall_scores.append(recall)
    precision_scores.append(precision)  # 新增 precision 的记录

    # 打印每次训练的性能指标
    print(f"Training Iteration {i+1} Results:")
    print(f"AUC={auc:.4f}, AUPR={aupr:.4f}, ACC={acc:.4f}, F1-score={f1:.4f}, MCC={mcc:.4f}, Recall={recall:.4f}, Precision={precision:.4f}")
    print()

# 计算性能指标的平均值
avg_auc = np.mean(auc_scores)
avg_aupr = np.mean(aupr_scores)
avg_acc = np.mean(acc_scores)
avg_f1 = np.mean(f1_scores)
avg_mcc = np.mean(mcc_scores)
avg_recall = np.mean(recall_scores)
avg_precision = np.mean(precision_scores)  # 新增 precision 的计算

# 打印训练五次的平均性能指标
print("Average Performance across 5 iterations:")
print("Average AUC:", avg_auc)
print("Average AUPR:", avg_aupr)
print("Average ACC:", avg_acc)
print("Average F1-score:", avg_f1)
print("Average MCC:", avg_mcc)
print("Average Recall:", avg_recall)
print("Average Precision:", avg_precision)


